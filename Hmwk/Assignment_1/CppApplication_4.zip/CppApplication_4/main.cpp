/* 
 * File:   main.cpp
 * Author: Paul Ellsworth
 *
 * Created on August 9, 2011, 2:48 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;
int main(int argc, char** argv) {
      cout<<"Hello World C++"<<endl;
      return 0;
}
